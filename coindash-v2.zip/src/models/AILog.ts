import mongoose, { Schema, models, model } from "mongoose";

const AILogSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    timestamp: { type: Date, default: Date.now, index: true },
    action: {
      type: String,
      enum: [
        "ANALYSIS",
        "BUY_SIGNAL",
        "SELL_SIGNAL",
        "HOLD",
        "POSITION_CHECK",
        "CRON_START",
        "CRON_END",
        "ERROR",
        "RECONCILE",
      ],
      default: "ANALYSIS",
    },
    pair: String,
    decision: String,
    confidence: Number,
    reasoning: String,
    executedTrade: { type: Boolean, default: false },
    tradeId: { type: Schema.Types.ObjectId, ref: "Trade" },
    aiProvider: String,
    meta: { type: Schema.Types.Mixed },
  },
  { timestamps: true }
);

AILogSchema.index({ userId: 1, timestamp: -1 });

export type AILogDoc = mongoose.InferSchemaType<typeof AILogSchema> & { _id: any };
export const AILog = (models.AILog as mongoose.Model<AILogDoc>) || model<AILogDoc>("AILog", AILogSchema);
